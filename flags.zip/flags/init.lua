minetest.register_craftitem("flags:flag_template", {
	description = "Flag Template",
	inventory_image = "flags_flag_template.png",
})

minetest.register_node("flags:american_flag", {
	description = "American Flag",
	drawtype = "mesh",
	mesh = "flags_american_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_american_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:american_flag",
	recipe = {
		{"dye:red", "dye:white", "dye:blue"},
		{"", "flags:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flag:flag_template", "flag:flag_template"}},
})

minetest.register_node("flags:russian_flag", {
	description = "Russian Flag",
	drawtype = "mesh",
	mesh = "flags_russian_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_russian_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:russian_flag",
	recipe = {
		{"dye:white", "", "default:steel_ingot"},
		{"dye:blue", "flag:flag_template", "default:steel_ingot"},
		{"dye:red", "", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:french_flag", {
	description = "French Flag",
	drawtype = "mesh",
	mesh = "flags_french_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_french_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:french_flag",
	recipe = {
		{"dye:blue", "dye:white", "dye:red"},
		{"", "flag:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})


minetest.register_node("flags:christian_flag", {
	description = "Christian Flag",
	drawtype = "mesh",
	mesh = "flags_christian_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_christian_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:christian_flag",
	recipe = {
		{"dye:red", "dye:blue", ""},
		{"dye:white", "flag:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:gadsden_flag", {
	description = "Gadsden Flag",
	drawtype = "mesh",
	mesh = "flags_gadsden_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_gadsden_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:gadsden_flag",
	recipe = {
		{"dye:yellow", "dye:black", ""},
		{"", "flags:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:confederate_flag", {
	description = "Confederate Flag",
	drawtype = "mesh",
	mesh = "flags_confederate_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_confederate_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:confederate_flag",
	recipe = {
		{"dye:red", "dye:blue", "dye:white"},
		{"", "flags:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:red_flag", {
	description = "Red Flag",
	drawtype = "mesh",
	mesh = "flags_red_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_red_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:red_flag",
	recipe = {
		{"dye:red", "", ""},
		{"", "flags:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:white_flag", {
	description = "White Flag",
	drawtype = "mesh",
	mesh = "flags_white_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_white_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:white_flag",
	recipe = {
		{"dye:white", "", ""},
		{"", "flags:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:british_flag", {
	description = "British Flag",
	drawtype = "mesh",
	mesh = "flags_british_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_british_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:british_flag",
	recipe = {
		{"dye:blue", "dye:red", "dye:white"},
		{"", "flag:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:german_flag", {
	description = "German Flag",
	drawtype = "mesh",
	mesh = "flags_german_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_german_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:german_flag",
	recipe = {
		{"dye:black", "", "default:steel_ingot"},
		{"dye:red", "flags:flag_template", "default:steel_ingot"},
		{"dye:yellow", "", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:canadian_flag", {
	description = "Canadian Flag",
	drawtype = "mesh",
	mesh = "flags_canadian_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_canadian_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:canadian_flag",
	recipe = {
		{"dye:red", "dye:white", "dye:red"},
		{"", "flags:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})

minetest.register_node("flags:italian_flag", {
	description = "Italian Flag",
	drawtype = "mesh",
	mesh = "flags_italian_flag.b3d",
	tiles = {name="flags_flag_pole.png", "flags_italian_flag.png"},
	groups = {oddly_breakable_by_hand = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	selection_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2}, --(-x = left, -y = down, -z = forward, x = right, y = up, z = back
	},
	collision_box = {
		type = "fixed",
		fixed = {-.2, -.5, -.2, .2, 4.5, .2},
	},
})

minetest.register_craft({
	output = "flags:italian_flag",
	recipe = {
		{"dye:green", "dye:white", "dye:red"},
		{"", "flags:flag_template", ""},
		{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
	},
	replacements = {{"flags:flag_template", "flags:flag_template"}},
})






